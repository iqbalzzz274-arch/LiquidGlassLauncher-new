package com.dexlite;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    ArrayList<AppInfo> all=new ArrayList<>(), shown=new ArrayList<>();
    AppAdapter adapter; GridView grid; ImageView wallpaper; View dim; SharedPreferences prefs;
    boolean labels=true; int iconSize=44; int columns=5; int dimAlpha=102;
    final int PICK_WALLPAPER=77;

    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("voidglass",0); labels=prefs.getBoolean("labels",true); iconSize=prefs.getInt("icon",44); columns=prefs.getInt("columns",5); dimAlpha=prefs.getInt("dim",102);
        wallpaper=findViewById(R.id.wallpaper); dim=findViewById(R.id.dim); grid=findViewById(R.id.apps);
        applyWallpaper(); applyDim();
        grid.setNumColumns(columns); adapter=new AppAdapter(this,shown); grid.setAdapter(adapter); load();
        EditText s=findViewById(R.id.search); s.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence x,int a,int c,int d){} public void afterTextChanged(android.text.Editable x){}
            public void onTextChanged(CharSequence x,int a,int b,int c){filter(x.toString());}
        });
        findViewById(R.id.settings).setOnClickListener(v->showSettings());
        findViewById(R.id.dockApps).setOnClickListener(v->{ s.setText(""); grid.smoothScrollToPosition(0); });
        startClock();
    }

    void startClock(){ final TextView c=findViewById(R.id.clock), d=findViewById(R.id.date); Runnable r=new Runnable(){public void run(){
        Date now=new Date(); c.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now)); d.setText(new SimpleDateFormat("EEE, d MMM  •  VOID GLASS",Locale.getDefault()).format(now).toUpperCase(Locale.getDefault())); c.postDelayed(this,1000);
    }}; r.run(); }

    void load(){ PackageManager pm=getPackageManager(); Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(i,PackageManager.MATCH_ALL)){
            String pkg=r.activityInfo.packageName; if(pkg.equals(getPackageName())) continue;
            all.add(new AppInfo(r.loadLabel(pm).toString(),pkg,r.activityInfo.name,r.loadIcon(pm)));
        }
        Collections.sort(all,(a,b)->a.name.compareToIgnoreCase(b.name)); shown.clear(); shown.addAll(all); adapter.notifyDataSetChanged(); }
    void filter(String q){ shown.clear(); String z=q.toLowerCase(Locale.getDefault()); for(AppInfo a:all) if(a.name.toLowerCase(Locale.getDefault()).contains(z)) shown.add(a); adapter.notifyDataSetChanged(); }

    void showSettings(){
        String[] items={"🎨  Change wallpaper","▦  Grid: "+columns+" columns","◉  Icon size: "+iconSize+"dp","Aa  App labels: "+(labels?"ON":"OFF"),"◐  Wallpaper dim: "+(dimAlpha*100/255)+"%","↻  Reset Void Glass"};
        new AlertDialog.Builder(this).setTitle("Void Glass Settings").setItems(items,(d,w)->{
            if(w==0) pickWallpaper();
            else if(w==1) chooseColumns();
            else if(w==2) chooseIconSize();
            else if(w==3){labels=!labels;prefs.edit().putBoolean("labels",labels).apply();adapter.notifyDataSetChanged();}
            else if(w==4) chooseDim();
            else { prefs.edit().clear().apply(); labels=true;iconSize=44;columns=5;dimAlpha=102;grid.setNumColumns(5);applyDim();adapter.notifyDataSetChanged(); }
        }).show();
    }
    void pickWallpaper(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_WALLPAPER); }
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data); if(r==PICK_WALLPAPER&&c==RESULT_OK&&data!=null&&data.getData()!=null){
        Uri u=data.getData(); try{getContentResolver().takePersistableUriPermission(u,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION); }catch(Exception ignored){}
        prefs.edit().putString("wall",u.toString()).apply(); applyWallpaper(); }
    }
    void applyWallpaper(){String s=prefs.getString("wall",""); if(!s.isEmpty()) try{wallpaper.setImageURI(Uri.parse(s));return;}catch(Exception ignored){} wallpaper.setImageDrawable(new ColorDrawable(Color.rgb(18,20,26)));}
    void applyDim(){dim.setBackgroundColor(Color.argb(dimAlpha,0,0,0));}
    void chooseColumns(){ final String[] x={"5 columns","6 columns"}; int checked=columns==6?1:0; new AlertDialog.Builder(this).setTitle("App drawer").setSingleChoiceItems(x,checked,(d,w)->{columns=w==1?6:5; prefs.edit().putInt("columns",columns).apply();grid.setNumColumns(columns);d.dismiss();}).show(); }
    void chooseIconSize(){ final String[] x={"40dp — compact","44dp — balanced","48dp — larger"}; int checked=iconSize==40?0:iconSize==48?2:1; new AlertDialog.Builder(this).setTitle("Icon size").setSingleChoiceItems(x,checked,(d,w)->{iconSize=w==0?40:w==2?48:44;prefs.edit().putInt("icon",iconSize).apply();adapter.notifyDataSetChanged();d.dismiss();}).show(); }
    void chooseDim(){ final String[] x={"30%","40%","50%","60%"}; int checked=dimAlpha<=76?0:dimAlpha<=102?1:dimAlpha<=127?2:3; new AlertDialog.Builder(this).setTitle("Wallpaper dim").setSingleChoiceItems(x,checked,(d,w)->{dimAlpha=new int[]{76,102,127,153}[w];prefs.edit().putInt("dim",dimAlpha).apply();applyDim();d.dismiss();}).show(); }

    static class AppInfo{String name,pkg,act;android.graphics.drawable.Drawable icon; AppInfo(String n,String p,String a,android.graphics.drawable.Drawable i){name=n;pkg=p;act=a;icon=i;}}
    class AppAdapter extends BaseAdapter{
        Context c;ArrayList<AppInfo>d; AppAdapter(Context c,ArrayList<AppInfo>d){this.c=c;this.d=d;}
        public int getCount(){return d.size();} public Object getItem(int p){return d.get(p);} public long getItemId(int p){return p;}
        public View getView(int p,View v,ViewGroup par){ LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);l.setPadding(2,5,2,2);
            ImageView im=new ImageView(c);im.setImageDrawable(d.get(p).icon);im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);l.addView(im,new LinearLayout.LayoutParams(iconSize,iconSize));
            if(labels){TextView t=new TextView(c);t.setText(d.get(p).name);t.setTextColor(Color.WHITE);t.setTextSize(10);t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);l.addView(t,new LinearLayout.LayoutParams(-1,28));}
            l.setOnClickListener(x->{try{Intent z=new Intent();z.setComponent(new ComponentName(d.get(p).pkg,d.get(p).act));c.startActivity(z);}catch(Exception e){}});
            l.setOnLongClickListener(x->{showAppInfo(d.get(p));return true;}); return l; }
    }
    void showAppInfo(AppInfo a){ new AlertDialog.Builder(this).setTitle(a.name).setMessage(a.pkg).setPositiveButton("Open",(d,w)->{Intent z=new Intent();z.setComponent(new ComponentName(a.pkg,a.act));startActivity(z);}).setNegativeButton("Close",null).show(); }
}
