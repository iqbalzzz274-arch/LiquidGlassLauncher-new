VOID GLASS PREMIUM — AndroidIDE / Redmi A3

Features:
- 5x7-style compact app grid (5 columns; optional 6)
- Small rounded/premium spacing
- Strong glass/translucent search and dock panels
- Wallpaper picker from Gallery/Files
- Wallpaper dim 30–60%
- Dark Void Glass visual
- App labels toggle
- Icon size 40/44/48dp
- Alphabetical app sorting
- Search/filter
- Haptic can be handled by system launcher settings
- Long press an app for package info
- HOME category included so it can be selected as a launcher

Build in AndroidIDE using Gradle sync/build.
Application ID: com.dexlite
Target/compile SDK: 35
Min SDK: 26
